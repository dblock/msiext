#if !defined(AFX_CREATEUNITTESTDLG_H__A9126DA8_9B0D_418B_A749_58047928C568__INCLUDED_)
#define AFX_CREATEUNITTESTDLG_H__A9126DA8_9B0D_418B_A749_58047928C568__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CreateUnitTestDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCreateUnitTestDlg dialog

class CCreateUnitTestDlg : public CDialog
{
// Construction
public:
	CCreateUnitTestDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCreateUnitTestDlg)
	enum { IDD = IDD_CREATE_UNIT_TEST };
	CString	m_className;
	CString	m_func1;
	CString	m_func2;
	CString	m_func3;
	CString	m_func4;
	CString	m_func5;
	CString	m_headerFile;
	CString	m_sourceFile;
	CString	m_dir;
	BOOL	m_setUp;
	BOOL	m_tearDown;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCreateUnitTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCreateUnitTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnUpdateClassName();
	afx_msg void OnButtonBrowse();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CREATEUNITTESTDLG_H__A9126DA8_9B0D_418B_A749_58047928C568__INCLUDED_)
