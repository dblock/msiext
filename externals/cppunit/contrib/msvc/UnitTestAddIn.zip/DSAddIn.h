// DSAddIn.h : header file
//

#if !defined(AFX_DSADDIN_H__0896B273_A4AD_4D45_B591_0409910B0C25__INCLUDED_)
#define AFX_DSADDIN_H__0896B273_A4AD_4D45_B591_0409910B0C25__INCLUDED_

#include "commands.h"

// {7CAA85B6-ECD7-4D54-AE4D-14F55753B341}
DEFINE_GUID(CLSID_DSAddIn,
0x7caa85b6, 0xecd7, 0x4d54, 0xae, 0x4d, 0x14, 0xf5, 0x57, 0x53, 0xb3, 0x41);

/////////////////////////////////////////////////////////////////////////////
// CDSAddIn

class CDSAddIn : 
	public IDSAddIn,
	public CComObjectRoot,
	public CComCoClass<CDSAddIn, &CLSID_DSAddIn>
{
public:
	DECLARE_REGISTRY(CDSAddIn, "UnitTestAddIn.DSAddIn.1",
		"UNITTESTADDIN Developer Studio Add-in", IDS_UNITTESTADDIN_LONGNAME,
		THREADFLAGS_BOTH)

	CDSAddIn() {}
	BEGIN_COM_MAP(CDSAddIn)
		COM_INTERFACE_ENTRY(IDSAddIn)
	END_COM_MAP()
	DECLARE_NOT_AGGREGATABLE(CDSAddIn)

// IDSAddIns
public:
	STDMETHOD(OnConnection)(THIS_ IApplication* pApp, VARIANT_BOOL bFirstTime,
		long dwCookie, VARIANT_BOOL* OnConnection);
	STDMETHOD(OnDisconnection)(THIS_ VARIANT_BOOL bLastTime);

protected:
	CCommandsObj* m_pCommands;
	DWORD m_dwCookie;

	static HHOOK m_hHookToolbarCreate;
	static LRESULT CALLBACK HookToolbarCreateFunc(int nCode, 
												  WPARAM wParam,
												  LPARAM lParam);

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DSADDIN_H__0896B273_A4AD_4D45_B591_0409910B0C25__INCLUDED)
