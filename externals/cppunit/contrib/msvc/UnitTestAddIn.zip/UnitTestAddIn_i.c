/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Apr 08 14:39:22 2002
 */
/* Compiler settings for C:\adev\CppSDK\UnitTestAddIn\UnitTestAddIn.odl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID LIBID_UnitTestAddIn = {0x8712DCB0,0xBE2D,0x4B82,{0xB1,0xCD,0x6E,0xC0,0xFE,0x5A,0xCA,0x50}};


const IID IID_ICommands = {0x8BE19C67,0x8541,0x4FA4,{0x91,0x26,0xD1,0x8D,0xF3,0x61,0xBC,0x2C}};


const CLSID CLSID_Commands = {0xDBDE8365,0x3B97,0x49F1,{0x8C,0x19,0x01,0x10,0x4D,0x90,0x47,0x09}};


const CLSID CLSID_ApplicationEvents = {0x129E2CDC,0xD3EF,0x48B3,{0x93,0x2E,0xA9,0x9F,0x17,0x38,0x90,0xDA}};


const CLSID CLSID_DebuggerEvents = {0xD8CD0585,0xD09D,0x4036,{0x97,0xD6,0xFE,0x93,0xF3,0xB6,0x66,0xDF}};


#ifdef __cplusplus
}
#endif

