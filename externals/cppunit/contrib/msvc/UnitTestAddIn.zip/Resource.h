//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UnitTestAddIn.rc
//
#define IDS_UNITTESTADDIN_LONGNAME      1
#define IDS_UNITTESTADDIN_DESCRIPTION   2
#define IDS_CMD_STRING                  3
#define IDR_TOOLBAR_MEDIUM              128
#define IDR_TOOLBAR_LARGE               129
#define IDD_CREATE_UNIT_TEST            129
#define IDC_CLASS_NAME                  1000
#define IDC_FUNC_1                      1001
#define IDC_FUNC_2                      1002
#define IDC_FUNC_3                      1003
#define IDC_FUNC_4                      1004
#define IDC_FUNC_5                      1005
#define IDC_HEADER_FILE                 1006
#define IDC_SOURCE_FILE                 1007
#define IDC_EDIT_DIR                    1008
#define IDC_BUTTON_BROWSE               1009
#define IDC_FUNC_6                      1010
#define IDC_CHECK_SET_UP                1011
#define IDC_CHECK_TEAR_DOWN             1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
