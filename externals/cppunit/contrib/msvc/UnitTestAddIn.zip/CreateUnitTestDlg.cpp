// CreateUnitTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "UnitTestAddIn.h"
#include "CreateUnitTestDlg.h"
#include "DirDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCreateUnitTestDlg dialog


CCreateUnitTestDlg::CCreateUnitTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCreateUnitTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCreateUnitTestDlg)
	m_className = _T("");
	m_func1 = _T("");
	m_func2 = _T("");
	m_func3 = _T("");
	m_func4 = _T("");
	m_func5 = _T("");
	m_headerFile = _T("");
	m_sourceFile = _T("");
	m_dir = _T("");
	m_setUp = FALSE;
	m_tearDown = FALSE;
	//}}AFX_DATA_INIT
}


void CCreateUnitTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCreateUnitTestDlg)
	DDX_Text(pDX, IDC_CLASS_NAME, m_className);
	DDX_Text(pDX, IDC_FUNC_1, m_func1);
	DDX_Text(pDX, IDC_FUNC_2, m_func2);
	DDX_Text(pDX, IDC_FUNC_3, m_func3);
	DDX_Text(pDX, IDC_FUNC_4, m_func4);
	DDX_Text(pDX, IDC_FUNC_5, m_func5);
	DDX_Text(pDX, IDC_HEADER_FILE, m_headerFile);
	DDX_Text(pDX, IDC_SOURCE_FILE, m_sourceFile);
	DDX_Text(pDX, IDC_EDIT_DIR, m_dir);
	DDX_Check(pDX, IDC_CHECK_SET_UP, m_setUp);
	DDX_Check(pDX, IDC_CHECK_TEAR_DOWN, m_tearDown);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCreateUnitTestDlg, CDialog)
	//{{AFX_MSG_MAP(CCreateUnitTestDlg)
	ON_EN_UPDATE(IDC_CLASS_NAME, OnUpdateClassName)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE, OnButtonBrowse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCreateUnitTestDlg message handlers

BOOL CCreateUnitTestDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

   char curDir[ 256 ];
   GetCurrentDirectory( 256, curDir );
   m_dir = curDir;

   m_func1 = "firstTest";
	UpdateData( FALSE );
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCreateUnitTestDlg::OnUpdateClassName() 
{
	UpdateData( TRUE );
	m_headerFile = m_className + ".h";
	m_sourceFile = m_className + ".cpp";
	UpdateData( FALSE );
}

void CCreateUnitTestDlg::OnButtonBrowse() 
{
   UpdateData( TRUE );

   CDirDialog dirDlg;
//   dirDlg.m_strInitDir = m_dir;
   dirDlg.m_strTitle = "Select directory";

   if( dirDlg.DoBrowse() )
   {
      m_dir = dirDlg.m_strPath;
      UpdateData( FALSE );
   }
}
