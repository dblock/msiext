#ifndef __code_generator_h
#define __code_generator_h

#include <string>
#include <vector>

class CodeGenerator
{
public:
   CodeGenerator( const char* className, const char* dir, std::vector< std::string >& funcs, bool setUp, bool tearDown );

   std::string getHeaderName() const { return headerName; }
   std::string getBodyName() const { return bodyName; }

   int generateCode();

private:
   int generateHeader();
   int generateBody();

   std::string className;
   std::string dir;
   bool setUp;
   bool tearDown;
   std::string headerName;
   std::string bodyName;

   std::vector< std::string > funcs;
};

#endif // __code_generator_h